package dom.java;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * @author vishnu
 *
 */
public class DomParser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url = "http://www.google.com/";

		try {
			
			Document doc = Jsoup.connect(url).get();
			String title = doc.title();
			System.out.println(title);
			Elements elements = doc.getAllElements();
			System.out.println("Please print all Html tags:");

			for (Element link : elements) {
				System.out.print(link.tagName() + " ,");
			}

			for (Element link : elements) {
				System.out.print(link.childNodes().get(0) + " ,");
			}

		} catch (Exception ex) {
			System.out.println("Generated Exception while parsing html:-" + ex);
		}

	}

}
